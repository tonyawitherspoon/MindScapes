# MindScapes — Master Brand Package
## May 2026 · Tonya Witherspoon
## Updated: Teacher at Heart section, AI Prompt Championship partner

📁 /website/ — Production website files
   • index.html         — Homepage (Three moves + purpose-built teams)
   • services.html      — Three engagement types + small business doorway
   • work.html          — Track record + partners (incl. AI Prompt Championship)
   • leadership.html    — Bio + TEACHER AT HEART + Civic Service + Ecosystem Roles
   • insights.html      — Speaking and publishing
   • inquiry.html       — Request a Brief form
   • styles.css         — All site styling
   • script.js, tonya.png

📁 /brand-documents/
   • mindscapes-brand-guide        — Updated with Layer Mark + Print Emerald caveat
   • mindscapes-language-toolkit   — 3 variants of 2+2=9 incl. "future is emergent"
   • mindscapes-origin-public, mindscapes-origin-personal

📁 /family-review/
   • mindscapes-briefing-for-andrew-cait — Updated with Layer Mark terminology
   • mindscapes-font-review              — 5 typography directions

---

LOCKED FOUNDATION (May 2026):
  Name: MindScapes  · Word: Layers.  · Line: Connection compounds.
  Headline: Innovation doesn't scale without the layers beneath it.
  Operating Principle: 2+2=9 (3 variants — keynote, explainer, bumper sticker)
  Approach: Vision · Connect · Operationalize (Three moves. One result.)
  Engagements: Advisory · Build & Launch · Speaking & Writing
  Logo system: Wordmark (primary) + Layer Mark (companion, family designing)

PENDING:
  Typography (5 directions on font review page)
  Logo from family team (Andrew + Cait)

TALENT PIPELINE (story now told on Leadership page):
  1999 DOE grant → WSU teaching → MINDSTORMS Competition → WSU AVP →
  Today: Nic Wentling (Moonbase Labs) + Ramsey Jamoul (AI Prompt Champ + UEA)
  — both former MINDSTORMS competitors, WSU students, now MindScapes partners.

---

TO RESUME WITH CLAUDE:
"Hey Claude — coming back to MindScapes brand work. The site is live at
https://tonyawitherspoon.github.io/MindScapes/. Andrew/Cait/Steve gave me
feedback: [paste it]. Let's pick up from there."

Connection compounds.
